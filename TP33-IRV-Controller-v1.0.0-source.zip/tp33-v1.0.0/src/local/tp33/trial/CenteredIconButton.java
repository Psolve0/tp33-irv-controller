package local.tp33.trial;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.widget.Button;

/** Centers the combined icon and short label, rather than pinning the icon to the edge. */
public final class CenteredIconButton extends Button {
    public CenteredIconButton(Context context){
        super(context);setAllCaps(false);setGravity(Gravity.CENTER);
        setMinHeight(dp(48));setPadding(dp(16),dp(8),dp(16),dp(8));
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom){
        super.onLayout(changed,left,top,right,bottom);
        Drawable icon=getCompoundDrawables()[0];if(icon==null)return;
        int textWidth=(int)Math.ceil(getPaint().measureText(getText().toString()));
        int inset=Math.max(dp(16),(getWidth()-icon.getBounds().width()-getCompoundDrawablePadding()-textWidth)/2);
        if(getPaddingLeft()!=inset||getPaddingRight()!=inset)setPadding(inset,dp(8),inset,dp(8));
    }
}
