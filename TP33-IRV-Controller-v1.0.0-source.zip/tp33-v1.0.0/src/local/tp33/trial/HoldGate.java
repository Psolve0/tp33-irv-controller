package local.tp33.trial;

/** Touch intent gate. Uses a monotonic time supplied by the caller. */
public final class HoldGate {
    public static final long DELAY_MS=250;
    private int id;
    private long began;
    private boolean active;
    public int id(){return id;}
    public boolean pending(){return id!=0&&!active;}
    public boolean begin(int command,long now){
        if(command==0||id!=0)return false;
        id=command;began=now;active=false;return true;
    }
    public int activate(long now){
        if(id==0||active||now-began<DELAY_MS)return 0;
        active=true;return id;
    }
    /** Returns a stop command only if this press actually activated. */
    public int cancel(){int stop=active?id:0;id=0;active=false;return stop;}
}
