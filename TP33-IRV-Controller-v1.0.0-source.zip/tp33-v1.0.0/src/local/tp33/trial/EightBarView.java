package local.tp33.trial;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public final class EightBarView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int value=-1;
    private final int color;
    private final String label;
    public EightBarView(Context c,String label,int color){super(c);this.label=label;this.color=color;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);setLevel(-1);}
    public void setLevel(int bars){value=bars;setContentDescription(label+(bars<0?", reading unavailable":", "+bars+" of 8 levels"));invalidate();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float density=getResources().getDisplayMetrics().density;
        float gap=3*density,w=(getWidth()-gap*7)/8f,h=Math.min(getHeight()-4*density,23*density),top=(getHeight()-h)/2;
        boolean dark=(getResources().getConfiguration().uiMode&android.content.res.Configuration.UI_MODE_NIGHT_MASK)==android.content.res.Configuration.UI_MODE_NIGHT_YES;
        int filled=color;
        if(label.equals("Battery")){int band=MeterLevels.batteryBand(value);filled=band==1?(dark?Color.rgb(255,117,123):Color.rgb(190,47,58)):band==2?(dark?Color.rgb(255,213,79):Color.rgb(179,132,0)):(dark?Color.rgb(100,205,147):Color.rgb(31,136,94));}if(dark&&Color.red(color)==Color.green(color)&&Color.green(color)==Color.blue(color)){int gray=Math.min(235,Color.red(color)+80);filled=Color.rgb(gray,gray,gray);}
        for(int i=0;i<8;i++){
            RectF r=new RectF(i*(w+gap),top,i*(w+gap)+w,top+h);paint.setStyle(Paint.Style.FILL);paint.setColor(value>=0&&i<value?filled:((getResources().getConfiguration().uiMode&android.content.res.Configuration.UI_MODE_NIGHT_MASK)==android.content.res.Configuration.UI_MODE_NIGHT_YES?Color.rgb(47,61,73):Color.rgb(203,214,223)));canvas.drawRoundRect(r,3*density,3*density,paint);
            if(value<0){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(density);paint.setColor(Color.rgb(189,139,53));canvas.drawRoundRect(r,3*density,3*density,paint);}
        }
    }
}
