package local.tp33.trial;

public final class MeterLevels {
    private MeterLevels(){}
    /** 0 = no filled bars, 1 = red, 2 = yellow, 3 = green. */
    public static int batteryBand(int bars){return bars<=0?0:bars<=2?1:bars<=5?2:3;}
    /** Each lit bar means that complete eighth has been reached. -1 is no reading. */
    public static int bars(int value,int fullScale){
        if(value<0||fullScale<=0)return -1;
        return (int)Math.min(8,((long)value*8)/fullScale);
    }
}
