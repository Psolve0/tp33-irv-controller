package local.tp33.trial;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final UUID RX=UUID.fromString("0000fff2-0000-1000-8000-00805f9b34fb"), TX=UUID.fromString("0000fff4-0000-1000-8000-00805f9b34fb"), CCCD=UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final String DEFAULT_ADDRESS="";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private BluetoothAdapter adapter;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private BluetoothLeScanner scanner;
    private boolean ready=false, connecting=false, scanning=false, foreground=true, closing=false, exitAfterClose=false;
    private long session=0, holdToken=0;
    private int held=0;
    private final HoldGate holdGate=new HoldGate();
    private Button touchedMotorButton;
    private String touchedMotorLabel;
    private TextView movementFeedback;
    private TextView status,telemetry,logView;
    private FrameLayout pageHost;
    private View mainPage,advancedPage,aboutPage;
    private int page=0;
    private Button connectionButton,findButton,refreshButton,stopButton,advancedButton,aboutButton;
    private TextView aboutPrompt,titleText;
    private LinearLayout titleBox;
    private boolean refreshSwitchPending,refreshMeterPending;
    private long refreshToken;
    private final HashMap<Integer,Button> motorButtons=new HashMap<>();
    private final HashMap<Integer,String> motorLabels=new HashMap<>();
    private final HashMap<String,EightBarView> meters=new HashMap<>();
    private final int[] meterRaw={-1,-1,-1,-1,-1,-1,-1};
    private long meterUpdated=0;
    private String lastRx="none",lastTx="none",lastRxTime="none",lastTxTime="none";
    private final RecentLog recentLog=new RecentLog();
    private final Runnable logTicker=new Runnable(){public void run(){renderLog();ui.postDelayed(this,1000);}};
    private EditText address;
    private LinearLayout root;
    private final ArrayList<View> controls=new ArrayList<>();
    private final HashMap<Integer,Button> states=new HashMap<>();
    private final HashMap<Integer,SwitchState> switchStates=new HashMap<>();
    private final HashSet<Integer> motorStopsOwed=new HashSet<>(), panelMotors=new HashSet<>();
    private final ArrayDeque<Op> queue=new ArrayDeque<>();
    private final Protocol.Parser parser=new Protocol.Parser();
    private Op inflight;
    private String exportText="";
    private final LinkedHashMap<String,String> found=new LinkedHashMap<>();
    private Runnable connectionTimeout;

    static class Op {
        final int id; final boolean on; final long created=SystemClock.elapsedRealtime();
        Op(int id,boolean on){this.id=id;this.on=on;}
    }
    @Override public void onCreate(Bundle b) {
        setTheme(isDark()?android.R.style.Theme_Material_NoActionBar:android.R.style.Theme_Material_Light_NoActionBar);
        super.onCreate(b);
        new File(getFilesDir(),"tp33-trial-log.txt").delete(); // Retire the previous accumulating internal log.
        adapter=((BluetoothManager)getSystemService(BLUETOOTH_SERVICE)).getAdapter();
        buildUi();
        log("TP33 IRV Controller 1.0.0 | rolling diagnostics | hold threshold=250ms | Android "+Build.VERSION.RELEASE+" | "+Build.MANUFACTURER+" "+Build.MODEL);
        updateControls();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(ink());t.setPadding(0,dp(7),0,dp(5));return t;}
    private void section(String s){TextView t=text(s,21);t.setTypeface(null,1);t.setPadding(0,dp(18),0,dp(8));root.addView(t);}
    private Button button(String s,LinearLayout parent,Runnable run){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setMinHeight(dp(48));parent.addView(b,new LinearLayout.LayoutParams(0,-2,1));card(b,0,false);b.setOnClickListener(v->{tap(b);run.run();});return b;}
    private Button iconButton(String label,LinearLayout parent,Runnable run){Button b=new CenteredIconButton(this);b.setText(label);parent.addView(b,new LinearLayout.LayoutParams(0,-2,1));card(b,0,false);b.setOnClickListener(v->{tap(b);run.run();});return b;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(0);root.addView(r);return r;}
    private ScrollView scrollPage(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(12),dp(18),dp(24));scroll.addView(root);return scroll;}
    private void buildUi(){
        pageHost=new FrameLayout(this);pageHost.setBackgroundColor(backdrop());setContentView(pageHost);
        pageHost.setOnApplyWindowInsetsListener((v,in)->{android.graphics.Insets b=in.getInsets(WindowInsets.Type.systemBars());v.setPadding(b.left,b.top,b.right,b.bottom);return in;});
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(1);
        ScrollView scroll=scrollPage();shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        titleBox=new LinearLayout(this);titleBox.setOrientation(1);titleBox.setPadding(dp(14),dp(10),dp(14),dp(10));
        titleText=text("IRV Panel Controller",22);titleText.setTypeface(null,1);titleText.setPadding(0,0,0,0);titleBox.addView(titleText);TextView model=text("TP33",14);model.setPadding(0,dp(2),0,0);titleBox.addView(model);root.addView(titleBox);
        connectionButton=new Button(this);connectionButton.setAllCaps(false);connectionButton.setTextSize(15);connectionButton.setMinHeight(dp(52));connectionButton.setGravity(Gravity.CENTER);connectionButton.setCompoundDrawablePadding(dp(12));root.addView(connectionButton,new LinearLayout.LayoutParams(-1,-2));
        connectionButton.setOnClickListener(v->{tap(connectionButton);if(ready||connecting||gatt!=null)disconnect();else if(address.getText().toString().trim().isEmpty()){showPage(1);message("Use Find TP33 or enter your panel address, then tap Connect.");}else connect();});
        section("Lights");switchPair("Awning light",1,"Entry light",12);switchPair("Porch light",16,"Step light",3);switchPair("Aisle light",2,null,0);
        section("Utilities");switchPair("Water pump",11,"Electric water heater",4);switchPair("LP gas water heater",7,"Tank heater",15);switchPair("Panel power",8,null,0);
        section("Slides");motorRow("Slide 1",19,"Slide 1 in",17,"Slide 1 out");motorRow("Slide 2",6,"Slide 2 in",5,"Slide 2 out");motorRow("Slide 3",10,"Slide 3 in",9,"Slide 3 out");
        section("Awnings");motorRow("Awning 1",14,"Awning 1 retract",13,"Awning 1 extend");motorRow("Awning 2",20,"Awning 2 retract",18,"Awning 2 extend");
        LinearLayout stop=row();stopButton=iconButton("Stop all movement",stop,()->stopAll());controls.add(stopButton);
        section("Levels");meterRow("Battery",0,Color.rgb(31,136,94));meterRow("Fresh water",1,Color.rgb(33,133,185));meterRow("Black water 1",2,Color.rgb(76,76,76));meterRow("Black water 2",3,Color.rgb(90,90,90));meterRow("Grey water 1",4,Color.rgb(111,111,111));meterRow("Grey water 2",5,Color.rgb(129,129,129));meterRow("Galley",6,Color.rgb(145,145,145));
        LinearLayout footer=new LinearLayout(this);footer.setPadding(dp(18),dp(5),dp(18),dp(8));advancedButton=iconButton("Advanced",footer,()->showPage(1));advancedButton.setCompoundDrawablePadding(dp(8));shell.addView(footer);mainPage=shell;pageHost.addView(mainPage,new FrameLayout.LayoutParams(-1,-1));
        advancedPage=scrollPage();pageHost.addView(advancedPage,new FrameLayout.LayoutParams(-1,-1));
        button("← Controls",row(),()->showPage(0));section("Advanced");
        section("Bluetooth connection");status=text("Disconnected",16);root.addView(status);
        root.addView(text("Saved device address",14));address=new EditText(this);address.setSingleLine(true);address.setText(getPreferences(0).getString("address",DEFAULT_ADDRESS));address.setHint("Bluetooth device address");address.setTextSize(16);root.addView(address);
        root.addView(text("Use Find TP33 to select your own panel, or enter its Bluetooth address here. No device address is built into this app. Changes take effect on the next connection.",14));button("Save address",row(),()->{String mac=address.getText().toString().trim().toUpperCase(Locale.US);if(!BluetoothAdapter.checkBluetoothAddress(mac)){message("Enter a valid Bluetooth address.");return;}getPreferences(0).edit().putString("address",mac).apply();message("Address saved for the next connection.");});
        LinearLayout tools=row();findButton=button("Find TP33",tools,()->scan());refreshButton=button("Refresh readings",tools,()->refreshReadings());
        root.addView(text("Find TP33 searches for a nearby panel. Refresh readings requests switch states and tank/battery readings. Green means a search or refresh is in progress.",14));
        section("Control guide");root.addView(text("Tap a light or utility button to switch it. Green/check is ON; red/minus is OFF. The amber caution icon means a confirmed state is not yet available. Tapping an unconfirmed switch requests its state rather than guessing. Indicators follow panel reports, not just button presses.",15));
        root.addView(text("For slides and awnings, the left icon is IN/retract and the right icon is OUT/extend. Hold for 250 milliseconds to start, then release to send STOP. Sliding off the button, a second finger, leaving the app, or opening Advanced cancels a pending hold or requests a stop. Each activation remains limited to five seconds; press again for another interval. The green movement icon reflects the panel’s reported active direction; it does not indicate travel position.",15));
        root.addView(text("Slide and awning positions are not available in the decoded protocol. Stopped does not establish fully extended or retracted.",15));
        root.addView(text("The eight-bar displays use the original app’s full-scale value of 8 for both tanks and battery. No bars means the reported empty/lowest level; eight means the reported full/highest level. They reproduce the panel reading, including sensor errors. Battery bars are a relative indication, not a calibrated charge percentage. All filled battery bars are red at levels 1–2, yellow at 3–5, and green at 6–8. Amber outlines mean no reading is available.",15));
        section("Troubleshooting");root.addView(text("If connection fails, make sure Bluetooth and Nearby devices permission are enabled and the panel is powered. Disconnect any other app, including nRF Connect, that is connected to TP33. Move closer and reconnect. This app connects directly using the saved address and does not explicitly request a new pairing; Android or the panel may still ask to pair again.",15));
        root.addView(text("Keep the physical panel reachable during movement. A lost Bluetooth link, phone crash, or terminated app can prevent a STOP from reaching the panel. If movement does not stop, use the physical control. A successful Bluetooth write alone does not prove physical stopping.",15));
        section("Live diagnostics");root.addView(text("Only the last 60 seconds can be shown, copied, or saved. History stays in memory, is bounded in size, and clears when the app restarts. Timestamps show app processing time. Snapshot captures the current app state and latest panel data, not a new simultaneous sensor measurement.",14));
        LinearLayout logs=row();button("Copy last minute",logs,()->copyLog());button("Save last minute",logs,()->saveLog());button("Snapshot",row(),()->showSnapshot());
        telemetry=text("",14);root.addView(telemetry);logView=text("",12);logView.setTypeface(android.graphics.Typeface.MONOSPACE);logView.setTextIsSelectable(true);ScrollView logScroll=new ScrollView(this);logScroll.setNestedScrollingEnabled(true);logScroll.addView(logView);root.addView(logScroll,new LinearLayout.LayoutParams(-1,dp(260)));
        aboutButton=button("About",row(),()->showPage(2));aboutButton.setCompoundDrawables(icon(1002,0,false,25),null,null,null);
        aboutPage=scrollPage();pageHost.addView(aboutPage,new FrameLayout.LayoutParams(-1,-1));button("← Advanced",row(),()->showPage(1));section("About");
        TextView name=text("TP33 IRV Controller",25);name.setTypeface(null,1);name.setPadding(dp(6),dp(18),dp(6),dp(14));root.addView(name);root.addView(text("Version 1.0.0 · October 16, 2026",17));
        root.addView(text("Requires Android 12 or later and Bluetooth Low Energy. Physically tested baseline: Samsung Galaxy S24 Ultra (SM-S928U), Android 17, TP33 panel. Other qualifying phones are not yet verified.",15));
        root.addView(text("Developed collaboratively by Charles Anderson and ChatGPT (OpenAI).\nPrimary software development: ChatGPT.\nProduct direction, co-design, and hardware testing: Charles Anderson.\nThese credits do not imply OpenAI endorsement.",15));
        root.addView(text(apkSize(),15));Button updates=button("Check for updates",row(),()->{});updates.setEnabled(false);updates.setAlpha(0.5f);root.addView(text("Update checking will be available when the app has a public home.",14));
        TextView details=text("Independent replacement controller for compatible TP33 panels. This is not the original iRV Controller app and is not affiliated with or endorsed by Patrick Industries or iRV Technologies. It implements the original Bluetooth command protocol with new app code; it does not emulate the panel hardware or modify its firmware.\n\nRuns locally with Bluetooth permissions. No Internet permission, accounts, analytics, or automatic uploads. The app does not automatically send diagnostics to anyone. Copy places diagnostics on your clipboard; Save creates a file where you choose. You decide whether to share that copy. Diagnostics can include your panel address and device information; review them before sharing.",16);details.setVisibility(View.GONE);root.addView(details);aboutPrompt=text("Tap the app name to expand implementation details ▾",14);root.addView(aboutPrompt);name.setOnClickListener(v->{tap(name);boolean expand=details.getVisibility()!=View.VISIBLE;details.setVisibility(expand?View.VISIBLE:View.GONE);aboutPrompt.setText(expand?"Tap the app name to collapse implementation details ▴":"Tap the app name to expand implementation details ▾");name.setContentDescription("TP33 IRV Controller. Tap to "+(expand?"collapse":"expand")+" implementation details.");});name.setContentDescription("TP33 IRV Controller. Tap to expand implementation details.");
        movementFeedback=text("",12);applyAppearance();showPage(0);
    }
    private void showPage(int which){
        stopHeld();if(which!=1)stopScan();page=which;mainPage.setVisibility(which==0?View.VISIBLE:View.GONE);advancedPage.setVisibility(which==1?View.VISIBLE:View.GONE);aboutPage.setVisibility(which==2?View.VISIBLE:View.GONE);renderLog();
    }
    private boolean isDark(){return (getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;}
    private int ink(){return isDark()?Color.rgb(229,237,242):Color.rgb(25,43,55);}
    private int backdrop(){return isDark()?Color.rgb(18,26,33):Color.rgb(222,232,240);}
    private int danger(){return isDark()?Color.rgb(255,117,123):Color.rgb(170,38,47);}
    private void tap(View v){v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);}
    private FunctionIcon icon(int id,int state,boolean pending,int size){return new FunctionIcon(id,state,pending,dp(size),isDark());}
    private String apkSize(){long bytes=new File(getApplicationInfo().sourceDir).length();return String.format(Locale.US,"App package (APK): %.1f KB\nInstalled storage, including data/cache, is shown in Android Settings → Apps → TP33 IRV → Storage.",bytes/1024.0);}
    private void card(Button b,int current,boolean pending){
        boolean dark=isDark();int fill=dark?(current==1?Color.rgb(31,65,53):current==0?Color.rgb(39,52,64):Color.rgb(65,55,33)):(current==1?Color.rgb(229,246,236):current==0?Color.rgb(245,249,252):Color.rgb(255,248,232));
        int edge=pending?Color.rgb(193,136,35):current==1?Color.rgb(83,158,118):dark?Color.rgb(87,106,121):Color.rgb(160,181,196);
        if(b==stopButton)edge=danger();
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setCornerRadius(dp(10));bg.setColor(fill);bg.setStroke(dp(1),edge);
        b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(50,100,155,185)),bg,null));b.setTextColor(b==stopButton?danger():ink());b.setElevation(dp(3));b.setTranslationZ(b.isPressed()?dp(1):0);b.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
    }
    private void tintTree(View v){
        if(v instanceof TextView){((TextView)v).setTextColor(ink());if(v instanceof EditText){((EditText)v).setHintTextColor(isDark()?Color.LTGRAY:Color.DKGRAY);((EditText)v).setBackgroundTintList(android.content.res.ColorStateList.valueOf(ink()));}}
        if(v instanceof Button)card((Button)v,0,false);
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)tintTree(g.getChildAt(i));}
        v.invalidate();
    }
    private void applyAppearance(){
        if(pageHost==null)return;pageHost.setBackgroundColor(backdrop());tintTree(pageHost);
        android.graphics.drawable.GradientDrawable titleBg=new android.graphics.drawable.GradientDrawable();titleBg.setColor(isDark()?Color.rgb(35,61,81):Color.rgb(188,211,229));titleBg.setCornerRadius(dp(10));titleBox.setBackground(titleBg);
        getWindow().setStatusBarColor(backdrop());getWindow().setNavigationBarColor(backdrop());getWindow().getInsetsController().setSystemBarsAppearance(isDark()?0:WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        for(int id:states.keySet())renderSwitch(id);renderMotorButtons();renderConnection();card(stopButton,0,false);stopButton.setCompoundDrawablePadding(dp(8));stopButton.setCompoundDrawables(icon(1003,0,false,25),null,null,null);advancedButton.setCompoundDrawables(icon(1001,0,false,25),null,null,null);aboutButton.setCompoundDrawables(icon(1002,0,false,25),null,null,null);
    }
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);stopHeld();setTheme(isDark()?android.R.style.Theme_Material_NoActionBar:android.R.style.Theme_Material_Light_NoActionBar);applyAppearance();}
    private void switchPair(String a,int idA,String b,int idB){LinearLayout r=row();switchRow(a,idA,r);if(b!=null)switchRow(b,idB,r);else r.addView(new View(this),new LinearLayout.LayoutParams(0,dp(76),1));}
    private void switchRow(String label,int id,LinearLayout r){
        Button b=new Button(this);b.setAllCaps(false);b.setTextSize(14);b.setGravity(Gravity.CENTER);b.setPadding(dp(8),dp(6),dp(8),dp(6));b.setCompoundDrawablePadding(dp(7));b.setTag(label);b.setIncludeFontPadding(false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(76),1);lp.setMargins(dp(3),dp(4),dp(3),dp(4));r.addView(b,lp);states.put(id,b);switchStates.put(id,new SwitchState());b.setOnClickListener(v->{tap(b);toggleSwitch(id);});renderSwitch(id);
    }
    private void renderSwitch(int id){
        Button b=states.get(id);SwitchState s=switchStates.get(id);if(b==null||s==null)return;String label=b.getTag().toString();String state=s.current()==1?"ON":s.current()==0?"OFF":"";b.setText(label+(state.isEmpty()?"":"\n"+state));b.setCompoundDrawables(icon(id,s.current(),s.pending(),28),null,null,null);b.setEnabled(ready&&!closing&&!s.pending());b.setAlpha(ready?1f:0.65f);card(b,s.current(),s.pending());b.setContentDescription(label+", "+(state.isEmpty()?"state not available":state.toLowerCase(Locale.US))+(s.pending()?", waiting for panel":", activate to switch"));
    }
    private void meterRow(String name,int index,int color){
        LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);TextView label=text(name,15);r.addView(label,new LinearLayout.LayoutParams(dp(118),dp(48)));EightBarView bars=new EightBarView(this,name,color);r.addView(bars,new LinearLayout.LayoutParams(0,dp(48),1));meters.put(name,bars);
    }
    private void renderMeters(){String[] names={"Battery","Fresh water","Black water 1","Black water 2","Grey water 1","Grey water 2","Galley"};for(int i=0;i<names.length;i++){EightBarView b=meters.get(names[i]);if(b!=null)b.setLevel(MeterLevels.bars(meterRaw[i],8));}}
    private void renderConnection(){
        if(connectionButton==null)return;int state=ready?1:connecting||closing?-1:0;String label=closing?"Disconnecting…":connecting?"Connecting…":ready?"Connected":"Connect";connectionButton.setText(label);connectionButton.setCompoundDrawables(icon(1000,state,connecting||closing,28),null,null,null);connectionButton.setEnabled(!closing);card(connectionButton,state,connecting||closing);connectionButton.setContentDescription(ready?"Bluetooth connected. Activate to disconnect":connecting?"Connecting. Activate to cancel":"Connect to TP33 over Bluetooth");
        if(findButton!=null){findButton.setText(scanning?"Searching…":"Find TP33");findButton.setEnabled(!scanning);card(findButton,scanning?1:0,false);}
        if(refreshButton!=null){boolean active=refreshSwitchPending||refreshMeterPending;refreshButton.setText(active?"Refreshing…":"Refresh readings");refreshButton.setEnabled(ready&&!closing&&!active);card(refreshButton,active?1:0,false);}
    }
    private void refreshReadings(){if(!ready||closing){message("Connect to TP33 first.");return;}refreshSwitchPending=true;refreshMeterPending=true;long token=++refreshToken;renderConnection();send(29,true);send(27,true);ui.postDelayed(()->{if(token==refreshToken&&(refreshSwitchPending||refreshMeterPending)){refreshSwitchPending=false;refreshMeterPending=false;renderConnection();log("Refresh ended without both response types");}},6000);}
    private void toggleSwitch(int id){
        if(!ready||closing){message("Connect to TP33 first.");return;}
        if(holdGate.pending())stopHeld();
        if(held!=0||!motorStopsOwed.isEmpty()||!panelMotors.isEmpty()){message("Release movement and wait for it to stop before switching.");return;}
        SwitchState s=switchStates.get(id);if(s.pending())return;
        int target=s.beginToggle();
        if(target<0){log("Unknown switch state; refresh requested "+id);send(29,true);message("Reading panel state. Tap again once ON or OFF appears.");return;}
        long revision=s.revision(), link=session;renderSwitch(id);log("TOGGLE "+id+" requested="+target);send(id,target==1);
        ui.postDelayed(()->{if(link==session&&s.pending()&&s.revision()==revision){log("TOGGLE confirmation timeout "+id);s.reset();renderSwitch(id);if(ready){send(29,true);message("Panel state not confirmed; refreshing. No command was retried.");}}},6000);
    }
    private void resetSwitchRequests(){for(int id:switchStates.keySet()){SwitchState s=switchStates.get(id);if(s.pending()){s.reset();renderSwitch(id);}}}
    private void motorRow(String label,int left,String ls,int right,String rs){root.addView(text(label,17));LinearLayout r=row();holdButton(ls,r,left);holdButton(rs,r,right);}
    private void holdButton(String name,LinearLayout r,int id){
        Button b=button("",r,()->{});b.setMinHeight(dp(52));b.setPadding(dp(8),dp(6),dp(8),dp(6));b.setGravity(Gravity.CENTER);b.setIncludeFontPadding(false);b.setContentDescription(name+", hold to move; release to stop");LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)b.getLayoutParams();lp.setMargins(dp(3),dp(4),dp(3),dp(4));b.setLayoutParams(lp);controls.add(b);motorButtons.put(id,b);motorLabels.put(id,name);renderMotorButtons();
        final float[] down=new float[2];
        final int slop=ViewConfiguration.get(this).getScaledTouchSlop();
        b.setOnTouchListener((v,e)->{
            int a=e.getActionMasked();
            if(a==MotionEvent.ACTION_DOWN){
                if(!ready||!foreground||closing||holdGate.id()!=0)return true;
                if(!panelMotors.isEmpty()||!motorStopsOwed.isEmpty()){message("Waiting for movement to stop. Use STOP ALL if needed.");return true;}
                if(!holdGate.begin(id,SystemClock.elapsedRealtime()))return true;
                down[0]=e.getX();down[1]=e.getY();touchedMotorButton=b;touchedMotorLabel="";
                long token=++holdToken;v.setPressed(true);renderMotorButtons();log("HOLD PENDING "+id);
                // Let ScrollView intercept a scroll during the pending interval.
                ui.postDelayed(()->{
                    if(token!=holdToken||holdGate.id()!=id)return;
                    if(!ready||!foreground||closing||!panelMotors.isEmpty()||!motorStopsOwed.isEmpty()){stopHeld();return;}
                    if(holdGate.activate(SystemClock.elapsedRealtime())!=id){stopHeld();return;}
                    held=id;renderMotorButtons();
                    b.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);b.getParent().requestDisallowInterceptTouchEvent(true);
                    log("HOLD START "+id);enqueue(new Op(id,true),true);
                    ui.postDelayed(()->{if(token==holdToken&&held==id){log("5-second movement limit");stopHeld();}},5000);
                },HoldGate.DELAY_MS);
                return true;
            }
            boolean outside=e.getX()<0||e.getY()<0||e.getX()>v.getWidth()||e.getY()>v.getHeight();
            boolean scrollIntent=holdGate.pending()&&(Math.abs(e.getX()-down[0])>slop||Math.abs(e.getY()-down[1])>slop);
            if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL||a==MotionEvent.ACTION_POINTER_DOWN||a==MotionEvent.ACTION_POINTER_UP||(a==MotionEvent.ACTION_MOVE&&(outside||scrollIntent))){if(holdGate.id()==id)stopHeld();v.setPressed(false);v.getParent().requestDisallowInterceptTouchEvent(false);return true;}
            return true;
        });
    }
    private void clearHoldUi(){
        if(touchedMotorButton!=null){touchedMotorButton.setPressed(false);touchedMotorButton.setText(touchedMotorLabel);touchedMotorButton.getParent().requestDisallowInterceptTouchEvent(false);touchedMotorButton=null;}renderMotorButtons();
    }
    private void renderMotorButtons(){for(int id:motorButtons.keySet()){Button b=motorButtons.get(id);int state=!ready?-1:panelMotors.contains(id)?1:0;boolean pending=holdGate.id()==id&&!panelMotors.contains(id);b.setText("");b.setCompoundDrawables(null,icon(id,state,pending,32),null,null);card(b,state,pending);b.setEnabled(ready&&!closing);b.setAlpha(ready?1f:0.65f);}}
    private boolean permissions(){return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED;}
    private boolean bluetooth(){
        if(!permissions()){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},101);return false;}
        if(adapter==null){message("This phone has no Bluetooth adapter.");return false;}
        if(!adapter.isEnabled()){startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return false;}return true;
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] grants){super.onRequestPermissionsResult(r,p,grants);if(r==101)message(permissions()?"Permission granted. Tap Connect or Find TP33.":"Nearby devices permission is needed to connect.");}
    private void connect(){
        if(!bluetooth())return;
        if(held!=0||closing||!motorStopsOwed.isEmpty()){message("Release the movement button and wait for the stop.");return;}
        if(ready||connecting){message("Already connected or connecting. Disconnect first to change devices.");return;}
        String mac=address.getText().toString().trim().toUpperCase(Locale.US);
        if(!BluetoothAdapter.checkBluetoothAddress(mac)){message("Enter a valid Bluetooth address, or use Find TP33.");return;}
        stopScan();closeLink();getPreferences(0).edit().putString("address",mac).apply();connecting=true;status.setText("Connecting…");renderConnection();log("CONNECT "+mac);
        try {gatt=adapter.getRemoteDevice(mac).connectGatt(this,false,callback,BluetoothDevice.TRANSPORT_LE);}
        catch(Exception e){log("Connect failed: "+e);closeLink();return;}
        final long s=session;connectionTimeout=()->{if(s==session&&!ready){log("Connection/setup timed out");closeLink();}};ui.postDelayed(connectionTimeout,30000);
    }
    private void scan(){
        if(!bluetooth())return;if(scanning)return;found.clear();scanner=adapter.getBluetoothLeScanner();if(scanner==null){message("Bluetooth scanning unavailable.");return;}
        scanning=true;renderConnection();message("Searching for TP33 for 10 seconds…");log("SCAN started");
        try{scanner.startScan(scanCallback);}catch(Exception e){scanning=false;renderConnection();log("Scan failed: "+e);return;}
        ui.postDelayed(()->{if(!scanning)return;stopScan();if(found.isEmpty()){message("No TP33 found. Try Connect using the saved address.");return;}String[] macs=found.keySet().toArray(new String[0]);String[] labels=new String[macs.length];for(int i=0;i<macs.length;i++)labels[i]=found.get(macs[i])+"\n"+macs[i];new AlertDialog.Builder(this).setTitle("Select TP33").setItems(labels,(d,n)->{address.setText(macs[n]);connect();}).setNegativeButton("Cancel",null).show();},10000);
    }
    private final ScanCallback scanCallback=new ScanCallback(){
        @Override public void onScanResult(int type,ScanResult r){ui.post(()->{String n=r.getScanRecord()==null?null:r.getScanRecord().getDeviceName();if(n!=null&&n.toUpperCase(Locale.US).contains("TP33"))found.put(r.getDevice().getAddress(),n);});}
        @Override public void onScanFailed(int code){ui.post(()->{scanning=false;renderConnection();log("SCAN failed "+code);message("Scan failed. Try the saved address.");});}
    };
    private void stopScan(){if(scanning&&scanner!=null)try{scanner.stopScan(scanCallback);}catch(Exception e){log("Stop scan: "+e);}scanning=false;renderConnection();}
    private final BluetoothGattCallback callback=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int result,int state){ui.post(()->{if(g!=gatt)return;log("Connection status="+result+" state="+state);if(result!=0||state==BluetoothProfile.STATE_DISCONNECTED){if(held!=0)log("LINK LOST DURING MOVEMENT: use physical panel to ensure stopped");closeLink();}else if(state==BluetoothProfile.STATE_CONNECTED){status.setText("Connected · discovering controls…");if(!g.discoverServices()){log("Service discovery rejected");closeLink();}}});}
        @Override public void onServicesDiscovered(BluetoothGatt g,int result){ui.post(()->{if(g!=gatt)return;if(result!=0){log("Discovery failed "+result);closeLink();return;}BluetoothGattCharacteristic rx=null;for(BluetoothGattService s:g.getServices())for(BluetoothGattCharacteristic c:s.getCharacteristics()){if(TX.equals(c.getUuid()))tx=c;if(RX.equals(c.getUuid()))rx=c;}if(tx==null||rx==null||(tx.getProperties()&BluetoothGattCharacteristic.PROPERTY_WRITE)==0){log("Expected TP33 characteristics missing");closeLink();return;}BluetoothGattDescriptor d=rx.getDescriptor(CCCD);if(d==null||!g.setCharacteristicNotification(rx,true)){log("Cannot enable notifications");closeLink();return;}boolean ok;if(Build.VERSION.SDK_INT>=33)ok=g.writeDescriptor(d,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)==BluetoothStatusCodes.SUCCESS;else{d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);ok=g.writeDescriptor(d);}if(!ok){log("Notification setup rejected");closeLink();}});}
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int result){ui.post(()->{if(g!=gatt)return;log("Notification setup status="+result);if(result!=0){message("Pairing/setup failed. Accept any pairing request, then reconnect.");closeLink();return;}ready=true;connecting=false;if(connectionTimeout!=null)ui.removeCallbacks(connectionTimeout);status.setText("Connected · TP33 ready");updateControls();send(29,true);send(27,true);});}
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int result){ui.post(()->{if(g!=gatt||inflight==null)return;Op done=inflight;inflight=null;log("WRITE "+done.id+"="+(done.on?1:0)+" status="+result);if(result==0&&Protocol.motor(done.id)&&!done.on){motorStopsOwed.remove(done.id);if(queue.isEmpty()&&!closing)queue.addLast(new Op(29,true));}if(result!=0){queue.clear();resetSwitchRequests();if(Protocol.motor(done.id)){log("Movement write failed: verify stopped at physical panel");holdGate.cancel();held=0;holdToken++;clearHoldUi();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(done.on)queue.addFirst(new Op(done.id,false));}message("Write failed ("+result+"). See diagnostic log.");}pump();});}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){if(RX.equals(c.getUuid())){byte[] copy=value.clone();ui.post(()->{if(g==gatt)receive(copy);});}}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){if(Build.VERSION.SDK_INT<33&&RX.equals(c.getUuid())){byte[] copy=c.getValue().clone();ui.post(()->{if(g==gatt)receive(copy);});}}
    };
    private void send(int id,boolean on){if(!ready||closing){message("Connect to TP33 first.");return;}if(holdGate.pending())stopHeld();if(id<27&&(held!=0||!motorStopsOwed.isEmpty()||!panelMotors.isEmpty())){message("Release movement and wait for it to stop before using another control.");return;}enqueue(new Op(id,on),false);}
    private void enqueue(Op op,boolean priority){if(!ready)return;if(priority)queue.addFirst(op);else{if(queue.size()>16){log("Queue full; tap again after writes complete");return;}queue.addLast(op);}pump();}
    private void pump(){
        if(!ready||gatt==null||tx==null||inflight!=null)return;
        while(!queue.isEmpty()){
            Op op=queue.removeFirst();
            if(op.on&&SystemClock.elapsedRealtime()-op.created>3000){log("Dropped stale ON/request "+op.id);SwitchState s=switchStates.get(op.id);if(s!=null){s.reset();renderSwitch(op.id);}continue;}
            if(Protocol.motor(op.id)&&op.on&&(held!=op.id||!foreground||closing)){log("Cancelled queued movement "+op.id);continue;}
            inflight=op;byte[] data=Protocol.command(op.id,op.on);boolean ok;
            try{if(Build.VERSION.SDK_INT>=33)ok=gatt.writeCharacteristic(tx,data,BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)==BluetoothStatusCodes.SUCCESS;else{tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);tx.setValue(data);ok=gatt.writeCharacteristic(tx);}}
            catch(Exception e){log("Write exception "+e);ok=false;}
            log("TX "+Protocol.hex(data));
            if(ok&&Protocol.motor(op.id)&&op.on)motorStopsOwed.add(op.id);
            if(!ok){inflight=null;log("Write could not start; verify panel if moving");queue.clear();resetSwitchRequests();holdGate.cancel();held=0;holdToken++;clearHoldUi();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);status.setText("Write rejected · reconnect");ready=false;updateControls();if(closing)closeLink();return;}
            final long s=session;ui.postDelayed(()->{if(s==session&&inflight==op){log("Write acknowledgement timed out. If moving, stop at physical panel.");closeLink();}},4000);return;
        }
        if(closing)closeLink();
    }
    private void stopHeld(){int pending=holdGate.id();holdGate.cancel();int id=held;held=0;holdToken++;clearHoldUi();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);queue.removeIf(op->Protocol.motor(op.id)&&op.on);if(id==0){if(pending!=0){log("HOLD CANCELLED before activation "+pending);movementFeedback.setText("Brief touch cancelled · no movement requested");}return;}movementFeedback.setText("Stop requested · ready after panel response");log("HOLD STOP "+id);enqueue(new Op(id,false),true);}
    private void stopAll(){holdGate.cancel();held=0;holdToken++;clearHoldUi();movementFeedback.setText("Stop requested for all movement");getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);queue.clear();resetSwitchRequests();for(int id:Protocol.MOTORS)queue.addLast(new Op(id,false));log("STOP ALL requested");pump();}
    private void disconnect(){stopScan();if(holdGate.pending())stopHeld();if(held==0&&motorStopsOwed.isEmpty()){closeLink();return;}closing=true;updateControls();queue.clear();holdGate.cancel();held=0;holdToken++;clearHoldUi();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);for(int id:new HashSet<Integer>(motorStopsOwed))queue.addLast(new Op(id,false));pump();long s=session;ui.postDelayed(()->{if(s==session&&closing){log("Stop/disconnect deadline; verify physical panel");closeLink();}},4000);}
    private void closeLink(){
        boolean uncertain=!motorStopsOwed.isEmpty();
        if(uncertain){log("Closing with movement-stop delivery uncertain. Verify physical panel.");message("Connection lost before stop was confirmed. Use the physical panel to ensure movement stops.");}
        session++;ready=false;connecting=false;closing=false;holdGate.cancel();held=0;holdToken++;clearHoldUi();queue.clear();inflight=null;motorStopsOwed.clear();panelMotors.clear();parser.reset();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        BluetoothGatt old=gatt;gatt=null;tx=null;if(old!=null){try{old.disconnect();old.close();}catch(Exception ignored){}}
        if(status!=null)status.setText(uncertain?"Disconnected · verify movement is stopped at physical panel":"Disconnected");if(movementFeedback!=null)movementFeedback.setText("Connect to use movement controls");for(SwitchState s:switchStates.values())s.reset();if(telemetry!=null)telemetry.setText("");java.util.Arrays.fill(meterRaw,-1);meterUpdated=0;refreshSwitchPending=false;refreshMeterPending=false;refreshToken++;renderMeters();updateControls();
        if(exitAfterClose){exitAfterClose=false;finish();}
    }
    private void updateControls(){for(View v:controls){v.setEnabled(ready&&!closing);v.setPressed(false);}for(int id:states.keySet())renderSwitch(id);renderMotorButtons();renderConnection();}
    private void panelState(int id,int value){SwitchState s=switchStates.get(id);if(s!=null){int old=s.current();s.observe(value);renderSwitch(id);if(id==8&&old!=value&&ready)ui.post(()->{if(ready&&!closing)send(29,true);});}}
    private void receive(byte[] bytes){
        log("RX "+Protocol.hex(bytes));int previous=parser.badChecksums;
        for(byte[] f:parser.feed(bytes)){
            int id=f[1]&255;
            if(id>=1&&id<=20){panelState(id,f[2]&255);if(Protocol.motor(id)){if(f[2]==0)panelMotors.remove(id);else panelMotors.add(id);}}
            else if(id==29){refreshSwitchPending=false;int bits=(f[2]&255)|((f[3]&255)<<8)|((f[4]&255)<<16);int[] ids={4,1,15,3,11,7,12,16,2};for(int i=0;i<ids.length;i++)panelState(ids[i],(bits>>i)&1);panelState(8,(bits>>23)&1);int[] mids={17,19,5,6,9,10,13,14,18,20};int[] mbits={9,10,11,12,13,14,16,17,18,19};panelMotors.clear();for(int i=0;i<mids.length;i++)if(((bits>>mbits[i])&1)!=0)panelMotors.add(mids[i]);}
            else if(id==27){refreshMeterPending=false;meterRaw[0]=f[9]&255;meterRaw[1]=f[2]&255;meterRaw[2]=f[3]&255;meterRaw[3]=f[4]&255;meterRaw[4]=f[5]&255;meterRaw[5]=f[6]&255;meterRaw[6]=f[7]&255;meterUpdated=SystemClock.elapsedRealtime();renderMeters();}

        }
        renderMotorButtons();renderConnection();
        if(previous!=parser.badChecksums)log("Parser checksum failures total: "+parser.badChecksums);
    }
    private void message(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private String wallTime(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.US).format(new Date());}
    private void log(String s){
        String stamp=wallTime();recentLog.add(SystemClock.elapsedRealtime(),stamp+" "+s+"\n");
        if(s.startsWith("RX ")){lastRx=s.substring(3);lastRxTime=stamp;}else if(s.startsWith("TX ")){lastTx=s.substring(3);lastTxTime=stamp;}
        renderLog();
    }
    private void renderLog(){
        if(logView==null||page!=1)return;String recent=recentLog.text(SystemClock.elapsedRealtime());logView.setText(recent.isEmpty()?"No events in the last minute.":recent);
        if(telemetry!=null)telemetry.setText(meterUpdated==0?"No meter reading received in this connection.":"Latest meter reading: "+Math.max(0,(SystemClock.elapsedRealtime()-meterUpdated)/1000)+" seconds ago");
    }
    private String readLog(){return "TP33 IRV Controller 1.0.0 · last 60 seconds\nCaptured "+wallTime()+"\n"+recentLog.text(SystemClock.elapsedRealtime());}
    private void copyText(String label,String value){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(label,value));message("Copied.");}
    private void copyLog(){copyText("TP33 last-minute diagnostics",readLog());}
    private void saveLog(){exportText=readLog();beginExport("TP33-last-minute-log.txt");}
    private void beginExport(String filename){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(i,201);}
    private String snapshot(){
        StringBuilder s=new StringBuilder("TP33 IRV Controller 1.0.0 · current-state snapshot\nCaptured "+wallTime()+"\nLatest received state, not a simultaneous physical measurement.\n");
        s.append("Android ").append(Build.VERSION.RELEASE).append(" | ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append('\n');
        s.append("Saved address: ").append(getPreferences(0).getString("address",DEFAULT_ADDRESS)).append('\n');
        s.append("Connection: ").append(ready?"ready":connecting?"connecting":"disconnected").append(" | closing=").append(closing).append('\n');
        s.append("Held command: ").append(held).append(" | pending hold: ").append(holdGate.pending()?holdGate.id():0).append('\n');
        s.append("Panel movement directions: ").append(panelMotors).append(" | unacknowledged stops: ").append(motorStopsOwed).append('\n');
        s.append("Queued writes: ").append(queue.size()).append(" | current write: ").append(inflight==null?"none":inflight.id+"="+(inflight.on?1:0)).append('\n');
        int[] ids={1,12,16,3,2,11,4,7,15,8};for(int id:ids){SwitchState state=switchStates.get(id);s.append(states.get(id).getTag()).append(": ").append(state.current()<0?"unconfirmed":state.current()==1?"ON":"OFF").append(state.pending()?" (request pending)":"").append('\n');}
        s.append("Latest meter values [battery,fresh,black1,black2,grey1,grey2,galley]: ").append(java.util.Arrays.toString(meterRaw)).append('\n');
        s.append("Meter age seconds: ").append(meterUpdated==0?"unavailable":Long.toString(Math.max(0,(SystemClock.elapsedRealtime()-meterUpdated)/1000))).append('\n');
        s.append("Parser checksum failures this connection: ").append(parser.badChecksums).append('\n');
        s.append("Latest TX at ").append(lastTxTime).append(": ").append(lastTx).append('\n');s.append("Latest RX at ").append(lastRxTime).append(": ").append(lastRx).append('\n');return s.toString();
    }
    private void showSnapshot(){
        final String captured=snapshot();ScrollView scroll=new ScrollView(this);TextView t=text(captured,13);t.setTypeface(android.graphics.Typeface.MONOSPACE);t.setTextIsSelectable(true);t.setPadding(dp(18),dp(12),dp(18),dp(12));scroll.addView(t);
        new AlertDialog.Builder(this).setTitle("Current-state snapshot").setView(scroll).setPositiveButton("Copy",(d,n)->copyText("TP33 snapshot",captured)).setNeutralButton("Save",(d,n)->{exportText=captured;beginExport("TP33-state-snapshot.txt");}).setNegativeButton("Close",null).show();
    }
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==201&&result==RESULT_OK&&data!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(exportText.getBytes("UTF-8"));message("Log saved.");}catch(Exception e){message("Could not save log: "+e.getMessage());}}}
    @Override protected void onResume(){super.onResume();foreground=true;ui.removeCallbacks(logTicker);ui.post(logTicker);}
    @Override protected void onPause(){foreground=false;ui.removeCallbacks(logTicker);stopScan();stopHeld();super.onPause();}
    @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(!focused)stopHeld();}
    @Override public void onBackPressed(){if(page==2){showPage(1);return;}if(page==1){showPage(0);return;}exitAfterClose=true;disconnect();}
    @Override protected void onDestroy(){ui.removeCallbacks(logTicker);stopScan();closeLink();super.onDestroy();}
}
