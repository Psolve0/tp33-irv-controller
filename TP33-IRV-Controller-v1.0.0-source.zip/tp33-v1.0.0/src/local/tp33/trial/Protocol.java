package local.tp33.trial;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Protocol {
    private Protocol() {}
    public static final int[] MOTORS = {13,14,18,20,19,17,6,5,10,9};
    public static boolean motor(int id) {
        for (int v : MOTORS) if (v == id) return true;
        return false;
    }
    public static byte[] command(int id, boolean on) {
        return new byte[]{(byte)128,(byte)id,(byte)(on?1:0),0,(byte)(128+id+(on?1:0))};
    }
    public static String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte v : b) { if(s.length()>0)s.append(' '); s.append(String.format("%02X",v&255)); }
        return s.toString();
    }
    public static final class Parser {
        private byte[] pending = new byte[0];
        public int badChecksums = 0;
        public void reset() { pending=new byte[0]; badChecksums=0; }
        public List<byte[]> feed(byte[] input) {
            byte[] data = Arrays.copyOf(pending,pending.length+input.length);
            System.arraycopy(input,0,data,pending.length,input.length);
            List<byte[]> frames = new ArrayList<>();
            int pos=0;
            while(pos<data.length) {
                if((data[pos]&255)!=128) {pos++;continue;}
                if(data.length-pos<2)break;
                int id=data[pos+1]&255;
                int len=id==27?12:id==29?7:(id>=1&&id<=20?6:0);
                if(len==0){pos++;continue;}
                if(data.length-pos<len)break;
                int checksum=id==27?10:id==29?5:4;
                int sum=0;for(int i=0;i<checksum;i++)sum+=data[pos+i]&255;
                if((sum&255)!=(data[pos+checksum]&255)){badChecksums++;pos++;continue;}
                frames.add(Arrays.copyOfRange(data,pos,pos+len));pos+=len;
            }
            pending=Arrays.copyOfRange(data,pos,data.length);
            return frames;
        }
    }
}
