package local.tp33.trial;

import java.util.ArrayDeque;

/** RAM-only rolling history; elapsed time is unaffected by wall-clock changes. */
public final class RecentLog {
    public static final long WINDOW_MS=60_000;
    private static final int MAX_ENTRIES=1200, MAX_CHARS=180_000;
    private static final class Entry {final long time;final String text;Entry(long t,String s){time=t;text=s;}}
    private final ArrayDeque<Entry> entries=new ArrayDeque<>();
    private int chars;
    public void add(long now,String line){
        prune(now);
        if(line.length()>MAX_CHARS)line=line.substring(line.length()-MAX_CHARS);
        entries.addLast(new Entry(now,line));chars+=line.length();
        while(entries.size()>MAX_ENTRIES||chars>MAX_CHARS)removeFirst();
    }
    private void removeFirst(){chars-=entries.removeFirst().text.length();}
    public void prune(long now){while(!entries.isEmpty()&&now-entries.peekFirst().time>WINDOW_MS)removeFirst();}
    public String text(long now){prune(now);StringBuilder s=new StringBuilder(chars);for(Entry e:entries)s.append(e.text);return s.toString();}
    public int size(long now){prune(now);return entries.size();}
}
