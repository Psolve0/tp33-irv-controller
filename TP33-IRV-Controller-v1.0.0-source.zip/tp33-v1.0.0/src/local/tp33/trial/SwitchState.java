package local.tp33.trial;

/** Confirmed panel state; a request never changes the displayed ON/OFF state. */
public final class SwitchState {
    private int current=-1, requested=-1;
    private long revision;
    public int current(){return current;}
    public boolean pending(){return requested!=-1;}
    public long revision(){return revision;}
    /** Returns desired 0/1 or -1 if unknown/busy. */
    public int beginToggle(){
        if(current<0||pending())return -1;
        requested=current==0?1:0;revision++;return requested;
    }
    public void observe(int state){
        current=(state==0||state==1)?state:-1;
        if(current==requested&&requested!=-1){requested=-1;revision++;}
    }
    public void reset(){current=-1;requested=-1;revision++;}
}
