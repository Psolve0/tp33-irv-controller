package local.tp33.trial;

import android.graphics.*;
import android.graphics.drawable.Drawable;
import java.util.regex.*;

/** Native, resolution-independent icons. Paths use a 40 x 40 coordinate grid. */
public final class FunctionIcon extends Drawable {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path;
    private final int state;
    private final boolean pending;
    private final int pixels;
    private final boolean badge;
    private final boolean dark;
    private final int command;
    public FunctionIcon(int command,int state,boolean pending,int pixels){this(command,state,pending,pixels,false);}
    public FunctionIcon(int command,int state,boolean pending,int pixels,boolean dark){this.command=command;this.dark=dark;this.state=state;this.pending=pending;this.pixels=pixels;this.badge=command<1001;path=parse(pathFor(command));setBounds(0,0,pixels,pixels);}
    public static String pathFor(int id){
        switch(id){
            case 1: return "M 4 10 L 30 10 L 34 18 L 4 18 Z M 8 18 L 8 32 M 19 22 L 19 26 M 14 23 L 12 26 M 24 23 L 26 26 M 14 30 L 24 30";
            case 12:return "M 7 34 L 7 5 L 25 5 L 25 34 M 4 34 L 28 34 M 20 21 L 20 22 M 29 9 L 35 9 L 35 17 L 29 17 Z M 29 21 L 27 24 M 33 22 L 33 26";
            case 16:return "M 4 18 L 19 5 L 34 18 M 8 15 L 8 34 L 30 34 L 30 15 M 16 34 L 16 23 L 23 23 L 23 34 M 10 19 L 12 19 M 10 22 L 12 22";
            case 3: return "M 4 33 L 12 33 L 12 25 L 20 25 L 20 17 L 28 17 L 28 9 L 35 9 M 5 26 L 8 26 M 15 18 L 17 18 M 23 10 L 25 10";
            case 2: return "M 5 5 L 5 34 M 34 5 L 34 34 M 13 9 L 26 9 L 29 17 L 10 17 Z M 19.5 17 L 19.5 22 M 12 26 L 9 29 M 19.5 27 L 19.5 32 M 27 26 L 30 29";
            case 11:return "M 4 28 L 9 28 L 9 16 L 14 16 M 26 16 L 32 16 L 32 9 L 36 9 M 10 32 L 30 32 M 15 27 L 15 32 M 25 27 L 25 32 M 20 9 C 6 9 6 29 20 29 C 34 29 34 9 20 9 Z M 20 13 L 20 24 M 15 16 L 25 22 M 25 16 L 15 22";
            case 4: return "M 9 7 Q 9 4 13 4 L 27 4 Q 31 4 31 7 L 31 31 Q 31 34 27 34 L 13 34 Q 9 34 9 31 Z M 15 4 L 15 1 M 25 4 L 25 1 M 22 10 L 15 21 L 21 21 L 18 29 L 26 17 L 20 17 Z";
            case 7: return "M 9 7 Q 9 4 13 4 L 27 4 Q 31 4 31 7 L 31 31 Q 31 34 27 34 L 13 34 Q 9 34 9 31 Z M 20 10 C 22 17 28 19 25 25 C 22 32 12 27 15 21 C 14 25 20 20 20 10 Z";
            case 15:return "M 5 12 L 33 12 L 33 31 L 5 31 Z M 12 12 L 12 7 L 19 7 L 19 12 M 10 26 Q 6 23 10 20 Q 14 17 10 14 M 19 26 Q 15 23 19 20 Q 23 17 19 14 M 28 26 Q 24 23 28 20 Q 32 17 28 14";
            case 8: return "M 19.5 4 L 19.5 19 M 12 9 C 0 16 5 34 19.5 34 C 34 34 39 16 27 9";
            case 19:case 6:case 10:return "M 5 4 L 5 35 M 5 10 L 30 10 L 30 30 L 5 30 M 25 20 L 11 20 M 17 14 L 11 20 L 17 26";
            case 17:case 5:case 9:return "M 5 4 L 5 35 M 5 10 L 30 10 L 30 30 L 5 30 M 11 20 L 25 20 M 19 14 L 25 20 L 19 26";
            case 14:case 20:return "M 4 8 L 28 8 C 38 8 38 21 28 21 C 19 21 19 8 28 8 M 35 15 L 35 35 M 25 28 L 5 28 M 11 22 L 5 28 L 11 34";
            case 13:case 18:return "M 4 8 L 28 8 C 38 8 38 21 28 21 C 19 21 19 8 28 8 M 35 15 L 35 35 M 5 28 L 25 28 M 19 22 L 25 28 L 19 34";
            case 1000:return "M 19 3 L 19 36 L 31 26 L 8 9 M 8 30 L 31 13 L 19 3";
            case 1001:return "M 15 4 L 24 4 L 25 10 L 30 13 L 35 11 L 39 19 L 34 23 L 33 28 L 36 33 L 29 38 L 24 34 L 18 34 L 14 38 L 7 33 L 10 28 L 9 22 L 4 19 L 8 11 L 13 13 L 16 10 Z M 21 14 C 11 14 11 29 21 29 C 31 29 31 14 21 14 Z";
            case 1003:return "M 12 3 L 28 3 L 37 12 L 37 28 L 28 37 L 12 37 L 3 28 L 3 12 Z M 11 20 L 29 20";
            case 1002:return "M 20 3 C 0 3 0 37 20 37 C 40 37 40 3 20 3 Z M 20 17 L 20 29 M 20 10 L 20 11";
            default:return "M 9 9 L 30 9 L 30 30 L 9 30 Z";
        }
    }
    private static Path parse(String s){
        Matcher m=Pattern.compile("[MLCQZ]|-?[0-9]+(?:\\.[0-9]+)?").matcher(s);java.util.ArrayList<String> tokens=new java.util.ArrayList<>();while(m.find())tokens.add(m.group());
        Path p=new Path();int i=0;while(i<tokens.size()){
            String cmd=tokens.get(i++);int n=cmd.equals("Z")?0:cmd.equals("C")?6:cmd.equals("Q")?4:2;float[] a=new float[n];for(int j=0;j<n;j++)a[j]=Float.parseFloat(tokens.get(i++));
            if(cmd.equals("M"))p.moveTo(a[0],a[1]);else if(cmd.equals("L"))p.lineTo(a[0],a[1]);else if(cmd.equals("C"))p.cubicTo(a[0],a[1],a[2],a[3],a[4],a[5]);else if(cmd.equals("Q"))p.quadTo(a[0],a[1],a[2],a[3]);else p.close();
        }return p;
    }
    @Override public void draw(Canvas canvas){
        Rect b=getBounds();int save=canvas.save();canvas.translate(b.left,b.top);canvas.scale(b.width()/40f,b.height()/40f);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2.1f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);paint.setColor(command==1000?(dark?Color.rgb(103,181,255):Color.rgb(23,111,196)):command==1003?(dark?Color.rgb(255,117,123):Color.rgb(170,38,47)):state==1?(dark?Color.rgb(117,222,166):Color.rgb(22,113,82)):(dark?Color.rgb(202,218,230):Color.rgb(76,93,107)));canvas.drawPath(path,paint);
        if(!badge){canvas.restoreToCount(save);return;}
        paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);canvas.drawCircle(33,33,6.5f,paint);
        paint.setColor(state==1?Color.rgb(23,137,91):state==0?Color.rgb(190,47,58):Color.rgb(183,118,14));canvas.drawCircle(33,33,4.8f,paint);
        paint.setColor(Color.WHITE);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.4f);
        if(state==1){canvas.drawLine(30.7f,33,32.3f,34.7f,paint);canvas.drawLine(32.3f,34.7f,35.4f,31.2f,paint);}else if(state==0)canvas.drawLine(30.8f,33,35.2f,33,paint);else{canvas.drawLine(33,30.7f,33,33.1f,paint);canvas.drawPoint(33,35,paint);}
        if(pending){paint.setColor(Color.rgb(198,129,18));paint.setStrokeWidth(1.5f);canvas.drawCircle(33,33,7,paint);}
        canvas.restoreToCount(save);
    }
    @Override public int getIntrinsicWidth(){return pixels;}
    @Override public int getIntrinsicHeight(){return pixels;}
    @Override public void setAlpha(int a){paint.setAlpha(a);}
    @Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
