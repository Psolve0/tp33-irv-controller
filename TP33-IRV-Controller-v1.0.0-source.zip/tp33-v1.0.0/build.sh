#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_JAR:?Set ANDROID_JAR to Android API 35 android.jar}"
: "${BUILD_TOOLS:?Set BUILD_TOOLS to Android Build Tools 35.0.0 directory}"
: "${ECJ_JAR:?Set ECJ_JAR to Eclipse ECJ 3.37.0 jar}"
: "${RELEASE_KEYSTORE:?Set RELEASE_KEYSTORE to your private PKCS12 file outside this source tree}"
: "${RELEASE_KEY_ALIAS:?Set RELEASE_KEY_ALIAS}"
: "${TP33_KEYSTORE_PASSWORD:?Set TP33_KEYSTORE_PASSWORD privately}"
: "${TP33_KEY_PASSWORD:?Set TP33_KEY_PASSWORD privately}"
mkdir -p build/classes build/test-classes
java -jar "$ECJ_JAR" -8 -nowarn -d build/test-classes src/local/tp33/trial/Protocol.java src/local/tp33/trial/HoldGate.java src/local/tp33/trial/SwitchState.java src/local/tp33/trial/RecentLog.java src/local/tp33/trial/MeterLevels.java tests/ProtocolTest.java tests/HoldGateTest.java tests/SwitchStateTest.java tests/RecentLogTest.java tests/MeterLevelsTest.java
java -cp build/test-classes ProtocolTest
java -cp build/test-classes HoldGateTest
java -cp build/test-classes SwitchStateTest
java -cp build/test-classes RecentLogTest
java -cp build/test-classes MeterLevelsTest
java -jar "$ECJ_JAR" -8 -nowarn -classpath "$ANDROID_JAR" -d build/classes src/local/tp33/trial/*.java
"$BUILD_TOOLS/aapt2" compile --dir res -o build/resources.zip
"$BUILD_TOOLS/aapt2" link -I "$ANDROID_JAR" --manifest AndroidManifest.xml -o build/unsigned.apk build/resources.zip
"$BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --min-api 31 --output build build/classes/local/tp33/trial/*.class
python3 - <<'PY'
import zipfile
with zipfile.ZipFile('build/unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
    z.write('build/classes.dex','classes.dex')
PY
"$BUILD_TOOLS/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
# Sign in a temporary directory, then copy the complete file into the project.
trial_temp="$(mktemp -d)"
trap 'rm -rf "$trial_temp"' EXIT
"$BUILD_TOOLS/apksigner" sign --ks "$RELEASE_KEYSTORE" --ks-key-alias "$RELEASE_KEY_ALIAS" --ks-pass env:TP33_KEYSTORE_PASSWORD --key-pass env:TP33_KEY_PASSWORD --out "$trial_temp/TP33-IRV-Controller-v1.0.0.apk" build/aligned.apk
"$BUILD_TOOLS/apksigner" verify --verbose "$trial_temp/TP33-IRV-Controller-v1.0.0.apk"
cp "$trial_temp/TP33-IRV-Controller-v1.0.0.apk" TP33-IRV-Controller-v1.0.0.apk
