import local.tp33.trial.SwitchState;

public final class SwitchStateTest {
    private static int checks;
    private static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
    public static void main(String[] args){
        SwitchState s=new SwitchState();
        check(s.current()==-1&&!s.pending(),"Unknown initially");
        check(s.beginToggle()==-1&&!s.pending(),"Unknown must not send a guessed command");
        s.observe(0);check(s.current()==0,"Observe physical OFF");
        check(s.beginToggle()==1&&s.pending(),"OFF requests ON");
        check(s.current()==0,"No optimistic ON");
        check(s.beginToggle()==-1,"Repeated taps suppressed until confirmed");
        long r=s.revision();s.observe(0);check(s.pending()&&s.current()==0&&s.revision()==r,"Old snapshot does not confirm target");
        s.observe(1);check(!s.pending()&&s.current()==1&&s.revision()!=r,"Matching panel ON confirms request");
        check(s.beginToggle()==0&&s.pending(),"ON requests OFF");
        check(s.current()==1,"No optimistic OFF");
        s.observe(0);check(!s.pending()&&s.current()==0,"Matching panel OFF confirms request");
        s.observe(1);check(s.current()==1&&!s.pending(),"Physical panel changes reflected without app request");
        check(s.beginToggle()==0,"Toggle uses external panel state");
        r=s.revision();s.reset();check(s.current()==-1&&!s.pending()&&s.revision()!=r,"Disconnect/failure/timeout reset state");
        check(s.beginToggle()==-1,"Cannot replay failed toggle");
        s.observe(7);check(s.current()==-1,"Invalid state not interpreted as ON");
        for(int i=0;i<20;i++){
            int state=i%2;s.observe(state);check(s.beginToggle()==1-state,"Alternating requested target");
            check(s.current()==state,"Retain confirmed state during request");
            s.observe(1-state);check(!s.pending()&&s.current()==1-state,"Confirm alternating target");
        }
        System.out.println(checks+" switch-state checks passed");
    }
}
