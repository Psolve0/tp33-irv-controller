import local.tp33.trial.MeterLevels;

public final class MeterLevelsTest {
    private static int checks;
    private static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
    public static void main(String[] args){
        for(int i=0;i<=8;i++)check(MeterLevels.bars(i,8)==i,"Original 0–8 scale "+i);
        check(MeterLevels.bars(-1,8)==-1,"No reading is separate from empty");
        check(MeterLevels.bars(0,8)==0,"Empty has no lit bars");
        check(MeterLevels.bars(8,8)==8,"Full has eight lit bars");
        check(MeterLevels.bars(255,8)==8,"Out of range cannot overflow bar count");
        check(MeterLevels.bars(Integer.MAX_VALUE,8)==8,"Integer overflow avoided");
        check(MeterLevels.bars(1,10)==0,"Do not light next incomplete eighth");
        check(MeterLevels.bars(5,10)==4,"Generic scale halfway");
        check(MeterLevels.bars(9,10)==7,"Incomplete final eighth remains unlit");
        check(MeterLevels.bars(0,0)==-1,"Invalid scale is unavailable");
        check(MeterLevels.batteryBand(-1)==0,"Unavailable has no color band");
        check(MeterLevels.batteryBand(0)==0,"Empty has no filled band");
        for(int i=1;i<=2;i++)check(MeterLevels.batteryBand(i)==1,"Low battery red "+i);
        for(int i=3;i<=5;i++)check(MeterLevels.batteryBand(i)==2,"Mid battery yellow "+i);
        for(int i=6;i<=8;i++)check(MeterLevels.batteryBand(i)==3,"High battery green "+i);
        System.out.println(checks+" meter checks passed");
    }
}
