import local.tp33.trial.Protocol;
import java.util.*;

public class ProtocolTest {
    static int checks=0;
    static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static byte[] bytes(String hex){String[] s=hex.split(" ");byte[] b=new byte[s.length];for(int i=0;i<s.length;i++)b[i]=(byte)Integer.parseInt(s[i],16);return b;}
    static byte[] join(byte[]... chunks){int n=0;for(byte[] c:chunks)n+=c.length;byte[] b=new byte[n];int p=0;for(byte[] c:chunks){System.arraycopy(c,0,b,p,c.length);p+=c.length;}return b;}
    public static void main(String[] args){
        check(Protocol.hex(Protocol.command(1,true)).equals("80 01 01 00 82"),"Verified awning on");
        check(Protocol.hex(Protocol.command(1,false)).equals("80 01 00 00 81"),"Verified awning off");
        byte[] meter=bytes("80 1B 00 08 00 08 00 00 00 08 B3 00");
        byte[] on=bytes("80 01 01 00 82 08 00"),off=bytes("80 01 00 00 81 08 00");
        byte[] stream=join(meter,on,meter,off,meter);
        for(int split=0;split<=stream.length;split++){
            Protocol.Parser p=new Protocol.Parser();List<byte[]> frames=new ArrayList<>();
            frames.addAll(p.feed(Arrays.copyOfRange(stream,0,split)));frames.addAll(p.feed(Arrays.copyOfRange(stream,split,stream.length)));
            check(frames.size()==5,"Frame count at split "+split);
            check(Arrays.equals(frames.get(0),meter)&&Arrays.equals(frames.get(2),meter)&&Arrays.equals(frames.get(4),meter),"Meter reconstruction");
            check(frames.get(1)[2]==1&&frames.get(3)[2]==0,"Awning transitions");
            check(p.badChecksums==0,"No false checksum failures");
        }
        for(int chunk=1;chunk<=20;chunk++){
            Protocol.Parser p=new Protocol.Parser();int n=0;for(int start=0;start<stream.length;start+=chunk)n+=p.feed(Arrays.copyOfRange(stream,start,Math.min(start+chunk,stream.length))).size();check(n==5,"Chunk size "+chunk);
        }
        Protocol.Parser p=new Protocol.Parser();byte[] corrupt=meter.clone();corrupt[10]^=1;
        List<byte[]> recovered=p.feed(join(new byte[]{0,8,0},corrupt,on,meter));
        check(recovered.size()==2&&p.badChecksums==1,"Corrupt frame resynchronization");
        // Switch snapshot with awning light + electric water + power; from original bit mapping.
        byte[] snapshot=bytes("80 1D 03 00 80 20 00");
        check(new Protocol.Parser().feed(snapshot).size()==1,"Snapshot checksum and length");
        p.feed(new byte[]{(byte)128,27});p.reset();check(p.feed(meter).size()==1,"Reset clears partial data");
        check(!Protocol.motor(1)&&Protocol.motor(13)&&Protocol.motor(19),"Lights are not motors");
        System.out.println(checks+" protocol checks passed");
    }
}
