import local.tp33.trial.HoldGate;

public final class HoldGateTest {
    private static int checks;
    private static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        for(int id:new int[]{13,14,18,20,19,17,6,5,10,9}){
            HoldGate g=new HoldGate();check(g.begin(id,1000),"Begin");
            check(!g.begin(id+1,1010),"Block overlapping fingers");
            check(g.activate(1001)==0,"Graze must not activate");
            check(g.activate(1249)==0,"249ms still pending");
            check(g.cancel()==0,"Early release requires no stop/write");
            check(g.activate(1300)==0,"Cancelled timer cannot activate");
            check(g.begin(id,2000),"Restart after early release");
            check(g.activate(2250)==id,"250ms activates correct direction");
            check(g.activate(2300)==0,"No duplicate activation");
            check(g.cancel()==id,"Release stops immediately with same ID");
            check(g.cancel()==0,"No duplicate stop");
            check(g.id()==0&&!g.pending(),"Idle after stop");
            check(g.begin(id,3000),"Begin before lifecycle cancellation");
            check(g.cancel()==0&&g.activate(4000)==0,"Focus/scroll cancellation blocks delayed start");
        }
        HoldGate g=new HoldGate();check(!g.begin(0,0),"Reject sentinel ID");
        check(g.begin(13,0)&&g.activate(1000)==13,"Late scheduler activates once");
        System.out.println(checks+" hold-gate checks passed");
    }
}
