import local.tp33.trial.RecentLog;

public final class RecentLogTest {
    private static int checks;
    private static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
    public static void main(String[] args){
        RecentLog log=new RecentLog();log.add(1000,"old\n");log.add(2000,"new\n");
        check(log.text(61000).equals("old\nnew\n"),"Keep exact sixty-second boundary");
        check(log.text(61001).equals("new\n"),"Expire old event even without incoming data");
        check(log.text(62001).isEmpty(),"Idle log becomes empty");
        for(int i=0;i<4000;i++)log.add(70000+i,"event "+i+"\n");
        check(log.size(74000)<=1200,"Fast bursts stay bounded by entry count");
        check(!log.text(74000).contains("event 0\n")&&log.text(74000).contains("event 3999\n"),"Preserve newest records");
        check(log.text(134000).isEmpty(),"Entire burst expires with elapsed time");
        char[] a=new char[200000];java.util.Arrays.fill(a,'x');log.add(150000,new String(a));
        check(log.text(150000).length()<=180000,"Oversized single event bounded");
        log.add(150001,"latest\n");check(log.text(150001).endsWith("latest\n"),"Keep newest after capacity pressure");
        for(int second=0;second<3600;second++)log.add(200000+second*1000,"second "+second+"\n");
        check(log.size(3799000)<=61,"Hour-long session retains at most one minute");
        check(!log.text(3799000).contains("second 0\n"),"Export excludes history");
        System.out.println(checks+" rolling-log checks passed");
    }
}
